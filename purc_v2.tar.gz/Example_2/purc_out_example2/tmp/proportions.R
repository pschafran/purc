
library(ggplot2)
library(cowplot)
library(ggrepel)
library(dplyr)
props <- read.delim("purc_5_proportions.tsv", sep = "	", header = TRUE)
len <- dim(props)[1]
width <- dim(props)[2]
plotList <- list()
counter = 0
for (row in 1:len){
  counter = counter + 1
  sample <- props[row,1]
  titlePlot <- ggplot() +
    annotate("text", x = -1000,y = 1,size = 5,label = sample)+
    theme_void()
  plotList[[counter]] <- titlePlot
  for (col in c(2,3)){
    counter = counter + 1
    if (col == 2){
      clusterMethod <- "OTUs"
    } else if (col == 3) { clusterMethod <- "ASVs"}
    else if (col == 4) {clusterMethod <- "ASVs No Priors"}
    numbers <- props[row,col]
    for (j in strsplit(numbers,",")){
      newList <- c()
      for (k in j){
        newList <- c(newList,as.numeric(k))
        data <- data.frame(
          group=LETTERS[1:length(newList)],
          value=sort(newList, decreasing = TRUE)
          )
      }
    }
  # Get the positions
  df2 <- data %>%
      mutate(csum = rev(cumsum(rev(value))),
             pos = value/2 + lead(csum, 1),
             pos = if_else(is.na(pos), value/2, pos))
  if (counter < 5){
  pie <- ggplot(df2, aes(x="", y=value, fill=group)) +
    geom_bar(stat="identity", width=1) +
    coord_polar("y", start=0, direction = -1) +
    theme_void() +
    theme(legend.position="none") +
    ggtitle(clusterMethod) +
    theme(plot.title = element_text(hjust = 0.5)) +
    geom_label_repel(data = df2, aes(y = pos, label = value), size = 4.5, nudge_x = 1, show.legend = FALSE) +
    scale_fill_brewer(palette = "Pastel1")
  } else {
    pie <- ggplot(data, aes(x="", y=value, fill=group)) +
      geom_bar(stat="identity", width=1) +
      coord_polar("y", start=0, direction = -1) +
      theme_void() +
      theme(legend.position="none") +
      ggtitle("") +
      theme(plot.title = element_text(hjust = 0.5)) +
      geom_label_repel(data = df2, aes(y = pos, label = value), size = 4.5, nudge_x = 1, show.legend = FALSE) +
      scale_fill_brewer(palette = "Pastel1")
  }
  plotList[[counter]] <- pie
  }
}
relwidths = c(3)
for (i in 1:width){
  relwidths = c(relwidths,1)
}
plotsPerPage = width*6
pdf("purc_5_proportions.pdf", 8.5, 11)
for (i in seq(1, length(plotList), plotsPerPage)) {
  print(plot_grid(plotlist = plotList[i:(i+(plotsPerPage-1))], ncol = width, rel_widths = relwidths))
}
dev.off()
    